import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecurityService {
  static const _storage = FlutterSecureStorage();

  static const String _passwordKey = "admin_password";

  static const String recoveryPassword = "dce_reset_26442";

  static Future<void> initialize() async {
    final existing = await _storage.read(key: _passwordKey);

    if (existing == null) {
      await _storage.write(
        key: _passwordKey,
        value: "dceadmin",
      );
    }
  }

  static Future<bool> verifyPassword(String input) async {
    final saved = await _storage.read(key: _passwordKey);
    return input == saved;
  }

  static bool verifyRecoveryPassword(String input) {
    return input == recoveryPassword;
  }

  static Future<void> changePassword(String newPassword) async {
    await _storage.write(
      key: _passwordKey,
      value: newPassword,
    );
  }
}
