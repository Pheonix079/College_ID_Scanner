import 'dart:convert';

import 'package:csv/csv.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../database/db_helper.dart';
import '../models/student.dart';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';

class SyncService {
  static String _buildCsvUrl(String input) {
    input = input.trim();

    final exp = RegExp(r'/d/([a-zA-Z0-9-_]+)');
    final match = exp.firstMatch(input);

    if (match != null) {
      final id = match.group(1);
      return "https://docs.google.com/spreadsheets/d/$id/export?format=csv";
    }

    return input;
  }

  static Future<String> _downloadImage(
    String url,
    String roll,
  ) async {
    try {
      final dir = await getApplicationDocumentsDirectory();

      final photoDir = Directory('${dir.path}/photos');

      if (!await photoDir.exists()) {
        await photoDir.create(recursive: true);
      }

      final filePath = '${photoDir.path}/$roll.jpg';

      await Dio().download(url, filePath);

      return filePath;
    } catch (e) {
      return "";
    }
  }

  static Future<void> syncStudents() async {
    final prefs = await SharedPreferences.getInstance();

    final rawUrl = prefs.getString("data_url");

    if (rawUrl == null || rawUrl.isEmpty) {
      throw Exception("CSV link not found");
    }

    final url = _buildCsvUrl(rawUrl);

    final response = await http.get(Uri.parse(url));

    if (response.statusCode != 200) {
      throw Exception("Failed to download CSV");
    }

    final csvString = utf8.decode(response.bodyBytes);

    final rows = const CsvToListConverter().convert(csvString);

    if (rows.length <= 1) {
      throw Exception("CSV is empty");
    }

    await DBHelper.clearTable();

    int count = 0;

    for (int i = 1; i < rows.length; i++) {
      final row = rows[i];

      if (row.isEmpty) continue;

      final roll = row[0].toString().trim();

      if (roll.isEmpty) continue;

      String localPhoto = "";

      if (row.length > 6) {
        final photoUrl = row[6].toString().trim();

        if (photoUrl.isNotEmpty) {
          localPhoto = await _downloadImage(
            photoUrl,
            roll,
          );
        }
      }

      final student = Student(
        roll: roll,
        name: row.length > 1 ? row[1].toString().trim() : "",
        year: row.length > 2 ? row[2].toString().trim() : "",
        branch: row.length > 3 ? row[3].toString().trim() : "",
        busPaid: row.length > 4 ? row[4].toString().trim() == "1" : false,
        busRouteNo: row.length > 5 ? row[5].toString().trim() : "",
        photoPath: localPhoto,
      );

      await DBHelper.insert(student);

      count++;
    }

    final time = DateFormat(
      'dd MMM yyyy, hh:mm a',
    ).format(DateTime.now());

    await prefs.setString(
      "last_sync",
      "Success: $count records ($time)",
    );
  }
}
