import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import '../models/student.dart';

class DBHelper {
  static Database? _db;

  static Future<Database> get db async {
    if (_db != null) return _db!;

    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }

    String dbPath;

    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      final docsDir = await getApplicationDocumentsDirectory();
      dbPath = join(docsDir.path, 'students.db');
    } else {
      dbPath = join(await getDatabasesPath(), 'students.db');
    }

    _db = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
        CREATE TABLE students(
  roll TEXT PRIMARY KEY,
  name TEXT,
  year TEXT,
  branch TEXT,
  bus_paid INTEGER,
  bus_route_no TEXT,
  photo_path TEXT
)
''');
      },
    );

    return _db!;
  }

  static Future<void> insert(Student s) async {
    final dbClient = await db;
    await dbClient.insert(
      'students',
      s.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  static Future<Student?> getStudent(String roll) async {
    final dbClient = await db;
    final res =
        await dbClient.query('students', where: 'roll=?', whereArgs: [roll]);

    if (res.isEmpty) return null;
    return Student.fromMap(res.first);
  }

  static Future<void> clearTable() async {
    final dbClient = await db;
    await dbClient.delete('students');
  }
}
