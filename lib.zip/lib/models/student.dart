class Student {
  final String roll;
  final String name;
  final String year;
  final String branch;
  final bool busPaid;
  final String busRouteNo;
  final String photoPath;

  Student({
    required this.roll,
    required this.name,
    required this.year,
    required this.branch,
    required this.busPaid,
    required this.busRouteNo,
    this.photoPath = "",
  });

  Map<String, dynamic> toMap() {
    return {
      'roll': roll,
      'name': name,
      'year': year,
      'branch': branch,
      'bus_paid': busPaid ? 1 : 0,
      'bus_route_no': busRouteNo,
      'photo_path': photoPath,
    };
  }

  factory Student.fromMap(Map<String, dynamic> map) {
    return Student(
      roll: map['roll'],
      name: map['name'],
      year: map['year'],
      branch: map['branch'],
      busPaid: map['bus_paid'] == 1,
      busRouteNo: map['bus_route_no'] ?? "",
      photoPath: map['photo_path'] ?? "",
    );
  }
}
