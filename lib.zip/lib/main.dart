import 'package:flutter/material.dart';
import 'screens/role_screen.dart';
import 'theme/app_theme.dart';
import 'services/security_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SecurityService.initialize();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dronacharya Student Verification',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: const RoleScreen(),
    );
  }
}
