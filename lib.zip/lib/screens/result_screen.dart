import 'dart:io';

import 'package:flutter/material.dart';

import '../models/student.dart';
import '../theme/app_theme.dart';
import '../widgets/app_shell.dart';

class ResultScreen extends StatelessWidget {
  final Student student;

  const ResultScreen({
    super.key,
    required this.student,
  });

  @override
  Widget build(BuildContext context) {
    final bool isPaid = student.busPaid;

    return AppShell(
      appBar: AppBar(
        title: const Text("Student Details"),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        child: Column(
          children: [
            PremiumPanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(22),
                        child: student.photoPath.isNotEmpty
                            ? Image.file(
                                File(student.photoPath),
                                height: 150,
                                width: 120,
                                fit: BoxFit.cover,
                                filterQuality: FilterQuality.low,
                                errorBuilder: (_, __, ___) {
                                  return _fallbackPhoto();
                                },
                              )
                            : _fallbackPhoto(),
                      ),
                      const SizedBox(width: 18),
                      Expanded(
                        child: SizedBox(
                          height: 150,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                student.name,
                                style: const TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w800,
                                  height: 1.2,
                                ),
                              ),
                              const SizedBox(height: 10),
                              _infoRow(
                                "Roll No",
                                student.roll,
                              ),
                              const SizedBox(height: 8),
                              _infoRow(
                                "Year",
                                student.year,
                              ),
                              const SizedBox(height: 8),
                              _infoRow(
                                "Branch",
                                student.branch,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.72),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Transport Information",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Row(
                          children: [
                            Icon(
                              isPaid ? Icons.check_circle : Icons.cancel,
                              color: isPaid ? Colors.green : Colors.red,
                              size: 30,
                            ),
                            const SizedBox(width: 12),
                            Text(
                              isPaid ? "FEES PAID" : "FEES NOT PAID",
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                color: isPaid
                                    ? Colors.green.shade700
                                    : Colors.red.shade700,
                                letterSpacing: 0.3,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 22),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 18,
                            vertical: 14,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.background,
                            borderRadius: BorderRadius.circular(
                              18,
                            ),
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.directions_bus,
                                size: 24,
                                color: AppTheme.primary,
                              ),
                              const SizedBox(width: 12),
                              Text(
                                student.busRouteNo.isEmpty
                                    ? "Route Not Assigned"
                                    : "Route ${student.busRouteNo}",
                                style: const TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.qr_code_scanner),
                label: const Text(
                  "Scan New ID",
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(
    String label,
    String value,
  ) {
    return Row(
      children: [
        SizedBox(
          width: 72,
          child: Text(
            label,
            style: TextStyle(
              fontSize: 14,
              color: AppTheme.textPrimary.withOpacity(0.6),
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }

  Widget _fallbackPhoto() {
    return Container(
      height: 150,
      width: 120,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
      ),
      child: const Icon(
        Icons.person,
        size: 60,
        color: Colors.grey,
      ),
    );
  }
}
