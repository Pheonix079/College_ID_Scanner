import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/sync_service.dart';
import '../theme/app_theme.dart';
import '../widgets/app_shell.dart';

enum _LogType {
  info,
  success,
  error,
}

class _LogLine {
  final String text;
  final _LogType type;

  const _LogLine(this.text, this.type);
}

class SyncScreen extends StatefulWidget {
  const SyncScreen({super.key});

  @override
  State<SyncScreen> createState() => _SyncScreenState();
}

class _SyncScreenState extends State<SyncScreen> {
  bool _loading = false;

  String lastSync = "Never";

  final List<_LogLine> _logs = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();

    if (!mounted) return;

    setState(() {
      lastSync = prefs.getString("last_sync") ?? "Never";
    });
  }

  void _addLog(String text, _LogType type) {
    _logs.insert(0, _LogLine(text, type));
  }

  Future<void> _sync() async {
    setState(() {
      _loading = true;
      _logs.clear();
    });

    _addLog("Starting sync...", _LogType.info);

    try {
      await SyncService.syncStudents();

      _addLog(
        "Database updated successfully.",
        _LogType.success,
      );

      await load();
    } catch (e) {
      _addLog(
        e.toString(),
        _LogType.error,
      );
    }

    if (!mounted) return;

    setState(() {
      _loading = false;
    });
  }

  Color _logColor(_LogType type) {
    switch (type) {
      case _LogType.success:
        return Colors.green;
      case _LogType.error:
        return Colors.red;
      case _LogType.info:
        return Colors.orange;
    }
  }

  IconData _logIcon(_LogType type) {
    switch (type) {
      case _LogType.success:
        return Icons.check_circle;
      case _LogType.error:
        return Icons.error;
      case _LogType.info:
        return Icons.info;
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppShell(
      appBar: AppBar(
        title: const Text("Sync Database"),
      ),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        children: [
          const SectionHeader(
            eyebrow: 'SYNC',
            title: 'Refresh your offline student records',
            subtitle:
                'Pull the latest spreadsheet data and rebuild the local database used for scanning and manual lookups.',
          ),
          const SizedBox(height: 24),
          PremiumPanel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Database Status",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 22),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEEDDDD),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.history,
                        color: Color(0xFFB00000),
                        size: 34,
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Text(
                          "Last Sync: $lastSync",
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  onPressed: _loading ? null : _sync,
                  icon: _loading
                      ? const SizedBox(
                          height: 18,
                          width: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.sync),
                  label: Text(
                    _loading ? "Updating..." : "Update Database",
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const PremiumPanel(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.shield_outlined,
                  size: 36,
                  color: Color(0xFF22577A),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Text(
                    "Sync clears old student rows and imports the latest valid records from your configured CSV source.",
                    style: TextStyle(
                      fontSize: 16,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (_logs.isNotEmpty) ...[
            const SizedBox(height: 22),
            PremiumPanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Sync Logs",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 18),
                  ..._logs.map(
                    (log) => Container(
                      margin: const EdgeInsets.only(bottom: 14),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: _logColor(log.type).withOpacity(0.08),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            _logIcon(log.type),
                            color: _logColor(log.type),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              log.text,
                              style: const TextStyle(
                                fontSize: 15,
                                height: 1.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
