import 'dart:convert';
import 'dart:io';

import 'package:csv/csv.dart';
import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../database/db_helper.dart';
import '../models/student.dart';

typedef SyncProgressCallback = void Function(String message);

class SyncService {
  static const int photoSyncConcurrency = 50;

  static final Dio _dio = Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 60),
      sendTimeout: const Duration(seconds: 60),
      followRedirects: true,
    ),
  );

  static const List<String> _expectedHeaders = [
    'roll',
    'name',
    'year',
    'branch',
    'bus_paid',
    'bus_route_no',
    'photo_url',
  ];

  // ---------------------------------------------------------------------------
  // PUBLIC METHODS
  // ---------------------------------------------------------------------------

  static Future<void> syncStudentData({
    SyncProgressCallback? onProgress,
  }) async {
    final prefs = await SharedPreferences.getInstance();

    try {
      onProgress?.call('Downloading CSV...');

      final rawUrl = prefs.getString('data_url');

      if (rawUrl == null || rawUrl.trim().isEmpty) {
        throw Exception('CSV link not found.');
      }

      final csvUrl = _buildCsvUrl(rawUrl);

      final response = await http
          .get(Uri.parse(csvUrl))
          .timeout(const Duration(seconds: 30));

      if (response.statusCode != 200) {
        throw Exception(
          'Failed to download CSV '
          '(HTTP ${response.statusCode})',
        );
      }

      onProgress?.call('Parsing CSV...');

      final csvString = utf8.decode(response.bodyBytes);
      final rows = const CsvToListConverter().convert(csvString);

      if (rows.length <= 1) {
        throw Exception('CSV is empty.');
      }

      _validateHeaders(rows.first);

      onProgress?.call('Preparing data...');

      final photoDir = await _getPhotoDirectory();
      final List<Student> students = [];

      for (int i = 1; i < rows.length; i++) {
        final row = rows[i];
        if (row.isEmpty) continue;

        final roll = row[0].toString().trim();
        if (roll.isEmpty) continue;

        final photoUrl = row.length > 6 ? row[6].toString().trim() : '';

        final photoPath =
            photoUrl.isNotEmpty ? '${photoDir.path}/$roll.jpg' : '';

        students.add(
          Student(
            roll: roll,
            name: row.length > 1 ? row[1].toString().trim() : '',
            year: row.length > 2 ? row[2].toString().trim() : '',
            branch: row.length > 3 ? row[3].toString().trim() : '',
            busPaid: row.length > 4 && row[4].toString().trim() == '1',
            busRouteNo: row.length > 5 ? row[5].toString().trim() : '',
            photoPath: photoPath,
            photoUrl: photoUrl,
          ),
        );
      }

      onProgress?.call('Saving database...');

      await DBHelper.batchInsert(students);

      await _saveStatus(
        'data_sync_status',
        'Success: ${students.length} records',
      );

      onProgress?.call(
        'Data sync completed: '
        '${students.length} records.',
      );
    } catch (e) {
      await _saveStatus(
        'data_sync_status',
        'Failed: $e',
      );
      rethrow;
    }
  }

  static Future<void> syncPhotos({
    SyncProgressCallback? onProgress,
  }) async {
    try {
      final students = await DBHelper.getAllStudents();

      final tasks = <Future<void> Function()>[];

      int completed = 0;

      for (final student in students) {
        if (student.photoUrl.isEmpty) continue;

        tasks.add(() async {
          await _syncSinglePhoto(student);
          completed++;

          onProgress?.call(
            'Photos: $completed / ${tasks.length}',
          );
        });
      }

      if (tasks.isEmpty) {
        onProgress?.call('No photos to sync.');
        return;
      }

      await _runWithConcurrencyLimit(
        tasks,
        concurrency: photoSyncConcurrency,
      );

      await _saveStatus(
        'photo_sync_status',
        'Success: $completed photos checked',
      );

      onProgress?.call(
        'Photo sync completed.',
      );
    } catch (e) {
      await _saveStatus(
        'photo_sync_status',
        'Failed: $e',
      );
      rethrow;
    }
  }

  // ---------------------------------------------------------------------------
  // PHOTO SYNC
  // ---------------------------------------------------------------------------

  static Future<void> _syncSinglePhoto(
    Student student,
  ) async {
    final file = File(student.photoPath);

    if (!await file.exists()) {
      await _downloadAndSave(student);
      return;
    }

    final needsUpdate = await _remoteImageChanged(student.photoUrl, file);

    if (needsUpdate) {
      await _downloadAndSave(student);
    }
  }

  static Future<bool> _remoteImageChanged(
    String url,
    File localFile,
  ) async {
    try {
      final response = await _dio.head(url);

      final remoteLength = int.tryParse(
            response.headers.value('content-length') ?? '',
          ) ??
          -1;

      final localLength = await localFile.length();

      if (remoteLength > 0 && remoteLength != localLength) {
        return true;
      }

      return false;
    } catch (_) {
      // If verification fails, assume the file is unchanged.
      return false;
    }
  }

  static Future<void> _downloadAndSave(
    Student student,
  ) async {
    final file = File(student.photoPath);

    if (!await file.parent.exists()) {
      await file.parent.create(
        recursive: true,
      );
    }

    await _dio.download(
      student.photoUrl,
      student.photoPath,
    );
  }

  // ---------------------------------------------------------------------------
  // CONCURRENCY
  // ---------------------------------------------------------------------------

  static Future<void> _runWithConcurrencyLimit(
    List<Future<void> Function()> tasks, {
    required int concurrency,
  }) async {
    int index = 0;

    Future<void> worker() async {
      while (true) {
        if (index >= tasks.length) {
          return;
        }

        final current = index++;
        await tasks[current]();
      }
    }

    await Future.wait(
      List.generate(
        concurrency,
        (_) => worker(),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // HELPERS
  // ---------------------------------------------------------------------------

  static Future<Directory> _getPhotoDirectory() async {
    final dir = await getApplicationDocumentsDirectory();

    final photoDir = Directory('${dir.path}/photos');

    if (!await photoDir.exists()) {
      await photoDir.create(
        recursive: true,
      );
    }

    return photoDir;
  }

  static String _buildCsvUrl(String input) {
    input = input.trim();

    final exp = RegExp(
      r'/d/([a-zA-Z0-9-_]+)',
    );

    final match = exp.firstMatch(input);

    if (match != null) {
      final id = match.group(1);
      return 'https://docs.google.com/'
          'spreadsheets/d/$id/export?format=csv';
    }

    return input;
  }

  static void _validateHeaders(
    List<dynamic> headerRow,
  ) {
    final headers = headerRow
        .map(
          (e) => e.toString().trim().toLowerCase(),
        )
        .toList();

    for (int i = 0; i < _expectedHeaders.length; i++) {
      if (i >= headers.length || headers[i] != _expectedHeaders[i]) {
        throw Exception(
          'Invalid CSV header.\n'
          'Expected: '
          '${_expectedHeaders.join(', ')}',
        );
      }
    }
  }

  static Future<void> _saveStatus(
    String key,
    String message,
  ) async {
    final prefs = await SharedPreferences.getInstance();

    final time = DateFormat(
      'dd MMM yyyy, hh:mm a',
    ).format(DateTime.now());

    await prefs.setString(
      key,
      '$message ($time)',
    );
  }
}
