import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../database/db_helper.dart';
import '../services/sync_service.dart';
import '../widgets/app_shell.dart';

class SyncScreen extends StatefulWidget {
  const SyncScreen({super.key});

  @override
  State<SyncScreen> createState() => _SyncScreenState();
}

class _SyncScreenState extends State<SyncScreen> {
  final TextEditingController _urlController = TextEditingController();

  bool _loading = true;

  String _dataSyncStatus = 'Never';
  String _photoSyncStatus = 'Never';
  int _studentCount = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _urlController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();

    _urlController.text = prefs.getString('data_url') ?? '';
    _dataSyncStatus = prefs.getString('data_sync_status') ?? 'Never';
    _photoSyncStatus = prefs.getString('photo_sync_status') ?? 'Never';
    _studentCount = await DBHelper.getStudentCount();

    if (!mounted) return;

    setState(() {
      _loading = false;
    });
  }

  Future<void> _saveUrl() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(
      'data_url',
      _urlController.text.trim(),
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('CSV URL saved successfully.'),
      ),
    );
  }

  Future<void> _showSyncDialog({
    required String title,
    required Future<void> Function(SyncProgressCallback onProgress) action,
  }) async {
    String progress = 'Starting...';
    bool completed = false;

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        // Start the sync only once.
        if (!completed) {
          completed = true;

          action((message) {
            progress = message;
            if (dialogContext.mounted) {
              (dialogContext as Element).markNeedsBuild();
            }
          }).then((_) {
            if (dialogContext.mounted) {
              Navigator.of(dialogContext).pop();
            }
          }).catchError((error) {
            if (dialogContext.mounted) {
              Navigator.of(dialogContext).pop();
            }

            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Sync failed: $error'),
                ),
              );
            }
          });
        }

        return AlertDialog(
          title: Text(title),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(),
              const SizedBox(height: 16),
              Text(
                progress,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        );
      },
    );

    await _load();
  }

  Widget _infoCard(String title, String value) {
    return Card(
      child: ListTile(
        title: Text(title),
        subtitle: Text(value),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppShell(
      appBar: AppBar(
        title: const Text('Sync Data'),
      ),
      child: _loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                TextField(
                  controller: _urlController,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'Google Sheets CSV URL',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                ElevatedButton(
                  onPressed: _saveUrl,
                  child: const Text('Save URL'),
                ),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  icon: const Icon(Icons.storage),
                  label: const Text('Sync Data'),
                  onPressed: () {
                    _showSyncDialog(
                      title: 'Syncing Data',
                      action: (onProgress) {
                        return SyncService.syncStudentData(
                          onProgress: onProgress,
                        );
                      },
                    );
                  },
                ),
                const SizedBox(height: 12),
                ElevatedButton.icon(
                  icon: const Icon(Icons.photo_library),
                  label: const Text('Sync Photos'),
                  onPressed: () {
                    _showSyncDialog(
                      title: 'Syncing Photos',
                      action: (onProgress) {
                        return SyncService.syncPhotos(
                          onProgress: onProgress,
                        );
                      },
                    );
                  },
                ),
                const SizedBox(height: 24),
                _infoCard(
                  'Students',
                  _studentCount.toString(),
                ),
                const SizedBox(height: 12),
                _infoCard(
                  'Data Sync Status',
                  _dataSyncStatus,
                ),
                const SizedBox(height: 12),
                _infoCard(
                  'Photo Sync Status',
                  _photoSyncStatus,
                ),
              ],
            ),
    );
  }
}
